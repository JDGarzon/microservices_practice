package co.analisys.gimnasio.service;

import co.analisys.gimnasio.dto.NotificacionDTO;
import org.springframework.stereotype.Service;
import java.util.List;
import co.analisys.gimnasio.dto.NotificacionHorarioDTO;
import org.springframework.amqp.rabbit.annotation.RabbitListener;

@Service
public class NotificacionService {

    @RabbitListener(queues = "notificacion.queue")
    public void recibirNotificacion(NotificacionDTO notificacion) {
        enviarNotificacion(notificacion);
    }

    public void enviarNotificacion(NotificacionDTO notificacion) {
        // Simular envío de notificación
        System.out.println("Notificación enviada a " + notificacion.getUsuarioId() + ": " + notificacion.getMensaje());
    }

    @RabbitListener(queues = "horario.queue")
    public void recibirHorario(NotificacionHorarioDTO notificacionHorario) {
        enviarNotificacionHorario(notificacionHorario);
    }

    public void enviarNotificacionHorario(NotificacionHorarioDTO notificacionHorario) {
        List<Long> usuariosId = notificacionHorario.getUsuariosId();
        for (Long usuarioId : usuariosId) {
            // Simular envío de notificación
            System.out.println("Notificación enviada a " + usuarioId + ": " + notificacionHorario.getMensaje());
        }
    }
}
package co.analisys.biblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificacionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
